/**
 * Esta clase es parte de la aplicaci�n "World of Zuul". 
 * "World of Zuul" es un texto basado en un juego de aventura
 * muy simple. 
 *
 * Esta clase contiene informaci�n acerca de un comando que fue
 * emitido por el usuario.
 * Un comando se compone actualmente de dos cadenas: una palabra
 * de comando y una segunda palabra (por ejemplo, si el comando
 * fue "tome mapa", a continuaci�n, las dos cadenas, obviamente,
 * son "tome" y "mapa").
 * 
 * La forma en que se utiliza es la siguiente: Los comandos 
 * se comprueban que sean palabras de comandos v�lidos. 
 * Si el usuario introduce un comando no v�lido (una palabra que 
 * no se conoce), entonces la palabra de comando es <null>.
 *
 * Si el comando ten�a una sola palabra, la segunda palabra es <null>.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 *
 * Traductores: Jose Cardilli y Mario Finos
 */

public class Comando
{
    private String palabraComando;
    private String segundaPalabra;

    /**
     * Crea un objeto comando. Primera y segunda palabra deben ser 
     * suministradas, pero cualquiera de las dos (o ambas) pueden
     * ser nulo.
     * @param primeraPalabra La primera palabra del comando. 
     *                       Null si el comando no fue reconocido.
     * @param sugundaPalabra La segunda palabra del comando.
     */
    public Comando(String primeraPalabra, String segundaPalabra)
    {
        palabraComando = primeraPalabra;
        this.segundaPalabra = segundaPalabra;
    }

    /**
     * Devuelve la palabra comando (la primera palabra) de este comando.
     * Si el comando no se entiende, el resultado es nulo.
     * @return La palabra comando.
     */
    public String getPalabraComando()
    {
        return palabraComando;
    }

    /**
     * @return La segunda palabra de este comando. 
     *         Devuelve null si no hay segunda palabra.
     */
    public String getSegundaPalabra()
    {
        return segundaPalabra;
    }

    /**
     * @return true si este comando no se entendi�.
     */
    public boolean esDesconocido()
    {
        return (palabraComando == null);
    }

    /**
     * @return true si el comando tiene una segunda palabra.
     */
    public boolean tieneSegundaPalabra()
    {
        return (segundaPalabra != null);
    }
}