

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PalabrasComandoTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class PalabrasComandoTest
{
    /**
     * Default constructor for test class PalabrasComandoTest
     */
    public PalabrasComandoTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void comando()
    {
        PalabrasComando palabras1 = new PalabrasComando();
        assertEquals(true, palabras1.esComando("ir"));
        assertEquals(true, palabras1.esComando("salir"));
        assertEquals(true, palabras1.esComando("ayuda"));
        assertEquals(false, palabras1.esComando("ayudar"));
    }
}

