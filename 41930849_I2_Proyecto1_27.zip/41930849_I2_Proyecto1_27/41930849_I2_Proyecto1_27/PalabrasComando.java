/**
 * Esta clase es parte de la aplicaci�n "World of Zuul". 
 * "World of Zuul" es un texto basado en un juego de aventura
 * muy simple. 
 * 
 * Esta clase contiene una enumeraci�n de todas las palabras
 * comando conocidas por el juego.
 * Se utiliza para reconocer los comandos que se escriben.
 *
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 *
 * Traductores: Jose Cardilli y Mario Finos
 */

public class PalabrasComando
{
    // un arreglo constante que contiene todas las
    // palabras comando v�lidas
    private static final String[] comandosValidos = {
        "ira", "salir", "ayuda"
    };

    /**
     * Constructor - inicializa las palabras comando.
     */
    public PalabrasComando()
    {
        // nada que hacer en este momento ...
    }

    /**
     * Comprueba si una cadena dada es una palabra de 
     * comando v�lida.
     * @return true si una determinada cadena es un 
     *              comando v�lido, false si no lo es.
     */
    public boolean esComando(String unaString)
    {
        for(int i = 0; i < comandosValidos.length; i++) {
            if(comandosValidos[i].equals(unaString))
                return true;
        }
        // si hemos llegado hasta aqu�, la cadena 
        // no se encontr� en los comandos
        return false;
    }
}
