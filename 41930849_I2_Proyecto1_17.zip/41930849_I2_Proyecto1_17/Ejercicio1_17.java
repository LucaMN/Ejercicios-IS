import java.util.Scanner;
/**
 * Clase que permite obtener el perimetro y la superficie de un circulo
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Ejercicio1_17
{
    
    private double radio;
    private Calculo calculo = new Calculo();
    /**
     * Constructor crea una instancia de la clase
     */
    public Ejercicio1_17()
    {
        
        
    }
    /**
     * Metodo que permite obtener la superficie de un circulo
     */
    public void obtenerSuperficie(){
        pedirDatos();
        System.out.println("La superficie del circulo es: "+(Math.PI * calculo.multiplicar(radio, radio)));
    }
    /**
     * Metodo que permite obtener el perimetro de un circulo
     */
    public void obtenerPerimetro(){
        pedirDatos();
        double resultado = calculo.multiplicar(Math.PI, radio);
        System.out.println("El perimetro del circulo es: "+calculo.multiplicar(2, resultado));
    }
    /**
     * Metodo pide el ingreso de datos y lo almacena
     */
    private void pedirDatos(){
        System.out.println("Ingrese la longitud del radio del  círculo");
        radio = verificarParametro();
    }
    /**
     * Metodo que pide un valor que sea distinto a cero
     * @return double valor Que resulta ser distinto a 0
     */
    private double verificarParametro(){
        Scanner sc = new Scanner(System.in);
        double valor = Math.abs (sc.nextDouble());
        while(valor == 0){
            System.out.println("Ingrese un numero distinto a 0");
            valor = Math.abs (sc.nextDouble());
        }
        return valor;
    }
}
