/**
 * Clase Habitacion - una habitaci�n en un juego de aventuras.
 *
 * Esta clase es parte de la aplicaci�n "World of Zuul". 
 * "World of Zuul" es un texto basado en un juego de aventura
 * muy simple. 
 *
 * Una "Habitaci�n" representa un lugar en el escenario del juego. 
 * Se conecta a otras habitaciones a trav�s de las salidas.
 * Las salidas est�n marcadas norte, este, sur, oeste.
 * Para cada direcci�n, la habitaci�n almacena una referencia a 
 * la habitaci�n vecina, o NULL si no hay salida en esa direcci�n.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 *
 * Traductores: Jose Cardilli y Mario Finos
 */
public class Habitacion 
{
    public String descripcion;
    public Habitacion salidaNorte;
    public Habitacion salidaSur;
    public Habitacion salidaEste;
    public Habitacion salidaOeste;

    /**
     * Crear una habitaci�n descrita "descripcion". 
     * Inicialmente, no tiene salidas. "descripcion" 
     * es algo as� como "cocina" o "un patio abierto."
     * @param descripcion  La descripci�n de la habitaci�n.
     */
    public Habitacion(String descripcion) 
    {
        this.descripcion = descripcion;
    }

    /**
     * Define las salidas de esta habitaci�n.
     * Cada direcci�n o bien lleva a otra
     * habitaci�n o es nulo (sin salida de all�).
     * @param norte La salida norte.
     * @param este La salida este.
     * @param sur La salida sur.
     * @param oeste La salida oeste.
     */
    public void setSalidas(Habitacion norte, Habitacion este, 
                         Habitacion sur, Habitacion oeste) 
    {
        if(norte != null)
            salidaNorte = norte;
        if(este != null)
            salidaEste = este;
        if(sur != null)
            salidaSur = sur;
        if(oeste != null)
            salidaOeste = oeste;
    }

    /**
     * @return La descripci�n de esta habitaci�n.
     */
    public String getDescripcion()
    {
        return descripcion;
    }

}
