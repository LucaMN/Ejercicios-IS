
/**
 * Esta clase permite realizar la suma y la multiplicacion 
 * de dos numeros.
 * 
 * @author (Mario Finos) 
 * @version (1.0)
 */
public class Calculo
{

    /**
     * Constructor de objetos de la clase Calculo
     */
    public Calculo()
    {
    }

    /**
     * Metodo para realizar la suma
     * 
     * @param  x   el primer valor a sumar
     *         y   el segundo valor a sumar
     * @return double resultado El resultado de la suma        
     */
    public double sumar(double x, double y)
    {
        return x + y;
    }

    /**
     * Metodo para realizar la multiplicacion
     * 
     * @param  x   el primer valor a multiplicar
     *         y   el segundo valor a multiplicar
     * @return double resultado El resultado de la multiplicacion        
     */
    public double multiplicar(double x, double y)
    {
        return x * y;
    }
    
}
