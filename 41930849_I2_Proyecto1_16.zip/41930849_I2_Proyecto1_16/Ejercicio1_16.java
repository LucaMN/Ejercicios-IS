import java.util.Scanner;
/**
 * Clase que permite obtener la superficie y perimetro de un rectangulo
 * 
 * @author lucas Nuñez
 * @version 1.0
 */
public class Ejercicio1_16
{
    private double base;
    private double altura;
    private Calculo calculo = new Calculo();
    /**
     * Constructor que iniciañiza una instancia de la clase
     */
    public Ejercicio1_16()
    {
        
        
    }
    /**
     * Metodo que permite obtener la superficie de un rectangulo
     */
    public void obtenerSuperficie(){
        System.out.println("Ingrese la base y la altura de un rectangulo para obtener su superficie");
        pedirParametro();
        System.out.println("El valor de la superficie de su rectangulo es: "+calculo.multiplicar(base, altura));
    }
    /**
     * Metodo que permite obtener el perimetro de un rectangulo
     */
    public void obtenerPerimetro(){
        System.out.println("Ingrese la base y la altura de un rectangulo para obtener su perimetro");
        pedirParametro();
        double base2 = calculo.multiplicar(2 , base);
        double altura2 = calculo.multiplicar(2 , altura);
        System.out.println("El valor del perimetro de su rectangulo es: "+calculo.sumar(base2 , altura2));
    }
    /**
     * Metodo que verifica los valores ingresados
     * @return double valor Retornara un valor si es distinto a 0
     */
    private double verificarParametro(){
        Scanner sc = new Scanner(System.in);
        double valor = Math.abs (sc.nextDouble());
        while(valor == 0){
            System.out.println("Ingrese un numero distinto a 0");
            valor = Math.abs (sc.nextDouble());
        }
        return valor;
    }
    /**
     * Metodo que pide el ingreso de datos
     */
    private void pedirParametro(){
        System.out.println("Ingrese la base");
        base = verificarParametro();
        System.out.println("Ingrese la altura");
        altura = verificarParametro();
    }
}
