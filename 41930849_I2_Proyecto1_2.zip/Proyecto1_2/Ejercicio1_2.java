import java.util.Scanner;
/**
 * Esta clase permite ingresar dos numeros y realizar
 * la suma de ambos, el producto y las potencias 
 * intercambiando las bases.
 * 
 * @author (Mario Finos) 
 * @version (1.0)
 */
public class Ejercicio1_2
{
        /**
     * Constructor de objetos de la clase Ejercicio1_2
     */
    public Ejercicio1_2()
    {
        System.out.println("Ingrese el primer numero");
        int a = validarNumero(ingresarNumero());
        System.out.println("Ingrese el segundo numero");
        int b = validarNumero(ingresarNumero());
        // Suma ambos valores y muestra el resultado
        int s =sumarNumero(a,b);
        // Multiplica ambos valores y muestra el resultado
        int m = multiplicarNumero(a,b);
        // Realiza la potencia con primer dato como base y muestra el resultado
        int pba = potencia( a,  b);
        // Realiza la potencia con segundo dato como base y muestra el resultado
        int pbb = potencia(b, a);
        // Determina si el resultado de la suma es el mayor de todos
        sumaEsMayor(s,  m,  pba,  pbb);
    }
    private int ingresarNumero(){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        return a;
    }
    private int validarNumero(int a){
        while (a < 0) {
            System.out.println("El dato no debe ser menor a cero, reingrese");
            Scanner sc = new Scanner(System.in);
            a = sc.nextInt();
        } 
        return a;
    }
    private int sumarNumero(int a, int b ){
        int s = a + b;
        System.out.println("El resultado de la suma es: " + s);
        return s;
    }
    private int multiplicarNumero(int a, int b){
        int m = a * b;
        System.out.println("El resultado de la multiplicacion es: " + m);
        return m;
    }
    private int potencia(int a, int b){
        int pba = (int)Math.pow(a,b);
        System.out.println("El resultado de " + a + " elevado a la "
                           + b + " es: " + pba);
        return pba;
    }
    private void sumaEsMayor(int s, int m, int pba, int pbb){
        if (s > m && s > pba && s > pbb) {
            System.out.println("El resultado de la suma es el mayor");
        } else {
            System.out.println("El resultado de la suma no es el mayor");
        }
    }
}
