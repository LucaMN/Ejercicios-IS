/**
 * Esta clase es parte de la aplicaci�n "World of Zuul". 
 * "World of Zuul" es un texto basado en un juego de aventura
 * muy simple. 
 *  
 * Los usuarios pueden caminar por algunos paisajes. Eso es todo. 
 * Realmente deber�a ampliarse para que sea m�s interesante!
 * 
 * Para jugar este juego, cree una instancia de esta clase y 
 * llame al m�todo "juego".
 * 
 * Esta clase principal crea e inicializa todas las dem�s: 
 * crea todas las habitaciones, crea el analizador y comienza
 * el juego. 
 *  
 * Tambi�n eval�a y ejecuta los comandos que devuelve el analizador.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 *
 * Traductores: Jose Cardilli y Mario Finos
 */

public class Juego 
{
    private Analizador analizador;
    private Habitacion habitacionActual;
        
    /**
     * Crea el juego e inicializa su mapa interno.
     */
    public Juego() 
    {
        creaHabitaciones();
        analizador = new Analizador();
    }

    /**
     * Crea todas las habitaciones y vincula sus salidas.
     */
    private void creaHabitaciones()
    {
        Habitacion exterior, teatro, bar, laboratorio, oficina;
      
        // crea las habitaciones
        exterior = new Habitacion("en el exterior de la entrada principal de "
                               + "la universidad");
        teatro = new Habitacion("en el anfiteatro");
        bar = new Habitacion("en el bar");
        laboratorio = new Habitacion("en el laboratorio de computaci�n");
        oficina = new Habitacion("en la oficina de administraci�n "
                               + "de computaci�n");
        
        // inicializa las salidas de las habitaci�nes
        exterior.setSalidas(null, teatro, laboratorio, bar);
        teatro.setSalidas(null, null, null, exterior);
        bar.setSalidas(null, exterior, null, null);
        laboratorio.setSalidas(exterior, oficina, null, null);
        oficina.setSalidas(null, null, null, laboratorio);

        habitacionActual = exterior;  // comienza el juego en el exterior
    }

    /**
     *  Rutina principal del juego. Bucles hasta el final del juego.
     */
    public void jugar() 
    {            
        imprimirBienvenida();

        // Entrar en el bucle de control principal.
        // Aqu� leemos repetidamente �rdenes y las ejecutamos
        // hasta que el juego ha terminado.
                
        boolean finalizado = false;
        while (! finalizado) {
            Comando comando = analizador.getComando();
            finalizado = procesarComando(comando);
        }
        System.out.println("Gracias por jugar. Adi�s.");
    }

    /**
     * Imprime el mensaje de apertura para el jugador.
     */
    private void imprimirBienvenida()
    {
        System.out.println();
        System.out.println("Bienvenido al mundo de Zuul!");
        System.out.println("Zuul es un nuevo juego de aventuras "
                           + "incre�blemente aburrido.");
        System.out.println("Escriba 'ayuda' si la necesita.");
        System.out.println();
        imprimirDondeEstoy();
    }

    /**
     * Dado un comando, procesa (es decir: ejecuta) el comando.
     * @param comando El comando a ser procesado.
     * @return true Si el mandato termina el juego, false en caso contrario.
     */
    private boolean procesarComando(Comando comando) 
    {
        boolean quiereSalir = false;

        if(comando.esDesconocido()) {
            System.out.println("No s� lo que quieres decir ...");
            return false;
        }

        String palabraComando = comando.getPalabraComando();
        if (palabraComando.equals("ayuda"))
            imprimirAyuda();
        else if (palabraComando.equals("ir"))
            irAHabitacion(comando);
        else if (palabraComando.equals("salir"))
            quiereSalir = salir(comando);
        else if (palabraComando.equals("ver"))
            imprimirDondeEstoy();
        return quiereSalir;
    }

    // implementaciones de comandos de usuario:
    
    /**
     * Imprime informaci�n de ayuda.
     * Aqu� imprimimos algunos mensajes enigm�ticos y est�pidos
     * y una lista de las palabras comando.
     */
    private void imprimirAyuda() 
    {
        System.out.println("Usted est� perdido. Usted est� solo.");
        System.out.println("Usted pasea por la universidad.");
        System.out.println();
        System.out.println("Sus palabras comando son:");
        System.out.println("   ir salir ayuda ver");
    }

    /**
     * Imprime el mensaje de apertura para el jugador.
     */
    private void imprimirDondeEstoy()
    {
        System.out.println("Usted esta " + habitacionActual.getDescripcion());
        System.out.print("Salidas: ");
        if(habitacionActual.salidaNorte != null)
            System.out.print("norte ");
        if(habitacionActual.salidaEste != null)
            System.out.print("este ");
        if(habitacionActual.salidaSur != null)
            System.out.print("sur ");
        if(habitacionActual.salidaOeste != null)
            System.out.print("oeste ");
        System.out.println();
    }

    /** 
     * Trata de ir a una direcci�n. Si hay una salida, ingresa a la
     * nueva sala, de lo contrario mostrar� un mensaje de error.
     */
    private void irAHabitacion(Comando comando) 
    {
        if(!comando.tieneSegundaPalabra()) {
            // si no hay una segunda palabra, no sabemos a d�nde ir ...
            System.out.println("�A d�nde quiere ir?");
            return;
        }

        String direccion = comando.getSegundaPalabra();

        // Trata de salir de la habitaci�n actual.
        Habitacion siguienteHabitacion = null;
        if(direccion.equals("norte")) {
            siguienteHabitacion = habitacionActual.salidaNorte;
        }
        if(direccion.equals("este")) {
            siguienteHabitacion = habitacionActual.salidaEste;
        }
        if(direccion.equals("sur")) {
            siguienteHabitacion = habitacionActual.salidaSur;
        }
        if(direccion.equals("oeste")) {
            siguienteHabitacion = habitacionActual.salidaOeste;
        }

        if (siguienteHabitacion == null) {
            System.out.println("No hay puerta!");
        }
        else {
            habitacionActual = siguienteHabitacion;
            imprimirDondeEstoy();
        }
    }

    /** 
     * Se ingres� "Salir". Comprueba el resto de la orden para ver
     * si realmente quiere salir del juego.
     * @return true, si este comando cierra el juego, false en caso contrario.
     */
    private boolean salir(Comando comando) 
    {
        if(comando.tieneSegundaPalabra()) {
            System.out.println("�Salir que?");
            return false;
        }
        else {
            return true;  // se�al que queremos salir de jugar
        }
    }
    
    
}
