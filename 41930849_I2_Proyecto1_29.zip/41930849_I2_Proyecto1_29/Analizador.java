import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Esta clase es parte de la aplicaci�n "World of Zuul". 
 * "World of Zuul" es un texto basado en un juego de aventura
 * muy simple. 
 * 
 * Este analizador lee la entrada del usuario y trata de 
 * interpretarlo como un comando "Adventure".
 * Cada vez que se llama se lee una l�nea desde la terminal y 
 * trata de interpretar la l�nea como un comando de dos palabras.
 * Devuelve el comando como un objeto de clase Comando.
 *
 * El analizador tiene un conjunto de palabras comando conocidas.
 * Se comprueba la entrada del usuario contra los comandos conocidos,
 * y si la entrada no es uno de los comandos conocidos, devuelve un
 * objeto de comando que est� marcado como un comando desconocido.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 2006.03.30
 *
 * Traductores: Jose Cardilli y Mario Finos
 */
public class Analizador 
{
    // mantiene todas las palabras comando v�lidas
    private PalabrasComando comandos;  
    // fuente de entrada de comando
    private Scanner lector;         
    /**
     * Crea un analizador para leer desde la ventana de terminal.
     */
    public Analizador() 
    {
        comandos = new PalabrasComando();
        lector = new Scanner(System.in);
    }

    /**
     * @return El siguiente comando del usuario.
     */
    public Comando getComando() 
    {
        // contendr� la l�nea de entrada completa
        String lineaDeEntrada;   
        String palabra1 = null;
        String palabra2 = null;

        System.out.print("> ");     // imprime el "prompt"

        lineaDeEntrada = lector.nextLine();

        // Encuentra un m�ximo de dos palabras en la l�nea.
        Scanner tokenizer = new Scanner(lineaDeEntrada);
        if(tokenizer.hasNext()) {
            // obtener la primera palabra
            palabra1 = tokenizer.next(); 
            if(tokenizer.hasNext()) {
                // obtener la segunda palabra
                palabra2 = tokenizer.next();
                // Nota: Nosotros ignoramos el resto de la entrada.
            }
        }

        // Comprueba si se conoce esta palabra.Si es as�, crea un
        // comando con �l. Si no es as�, crea una orden de "nulo"
        // (por comando desconocido).
        if(comandos.esComando(palabra1)) {
            return new Comando(palabra1, palabra2);
        }
        else {
            return new Comando(null, palabra2); 
        }
    }
}
