    import java.util.Scanner;
    /**
     * Esta clase simula una calculadora sencilla.
     * 
     * @author (Mario Finos) 
     * @version (1.0)
     */
    public class Ejercicio1_4
    {
        // Variable de instancia de tipo Nucleo
        private Nucleo n = new Nucleo();
        // Variable de instancia de tipo Scanner
        private Scanner sc = new Scanner(System.in);
        /**
         * Constructor de objetos de la clase Calculadora
         */
        public Ejercicio1_4()
        {
            inicializar();
            realizarCalculos();
        }
    
        /**
         * Inicializa la calculadora, asignando cero
         * a "resultado" (Nucleo)
         */
        public void inicializar()
        {
            n.setResultado(0);
        }
    
        /**
         * Realiza un ciclo repetitivo hasta que el operador
         * decida finalizar. Para cada ciclo solicita el tipo
         * de calculo a resolver y el valor a aplicar en ese
         * calculo.
         */
        public void realizarCalculos()
        {
            
            // Solicita el tipo de calculo a realizar por primera vez,
            // al finalizar un calculo lo solicita nuevamente, ya que
            // el tipo de calculo forma parte de la condicion para 
            // continuar o salir
            int t = ingresarTipoDeCalculo();
            // Realiza un ciclo repetitivo hasta que ingrese "5"
            while (t != 5){
                System.out.println("Ingrese el valor a aplicar: ");
                switch (t){
                    case 1:
                            // Código a ejecutar si la variable es igual a "1"
                            // Solicita el valor por teclado y lo envia como 
                            // parametro al metodo calcular de Nucleo
                            n.suma(sc.nextInt());
                            break;
                            case 2:
                            // Código a ejecutar si la variable es igual a "2"
                            // Solicita el valor por teclado y lo envia como 
                            // parametro al metodo calcular de Nucleo
                            n.multiplicar(sc.nextInt());
                            break;
                            case 3:
                            // Código a ejecutar si la variable es igual a "3"
                            // Solicita el valor por teclado y lo envia como 
                            // parametro al metodo calcular de Nucleo
                            n.resta(sc.nextInt());
                            break;
                            case 4:
                            // Código a ejecutar si la variable es igual a "4"
                            // Solicita el valor por teclado y lo envia como 
                            // parametro al metodo calcular de Nucleo
                            n.division(sc.nextInt());
                            default:
                }
                // Imprime el resultado
                System.out.println("Resultado: " + n.getResultado());
                // Solicita nuevamente el tipo de calculo
                t = ingresarTipoDeCalculo();
            }    
        }

        /**
        * Ingresa y valida el tipo de calculo a realizar.
        * tipos validos: "1" - Suma, "2" - Resta, "3" - Divide
        *                "4" - Multiplica, "5" - Fin
        */
       public int ingresarTipoDeCalculo()
       {
           System.out.println("Ingrese el tipo de cálculo que desea: ");
           System.out.println("1 - Suma"+" 2 - Resta "+" 3 - Divide "+
                              " 4 - Multiplica "+" 5 - Fin");
           int t;
           // Solicita el tipo de calculo tantas veces como sea necesario,
           // hasta que ingrese un valor valido
           t = sc.nextInt();
           while (t < 1 || t > 5){
               System.out.println("Tipo inválido, reingrese");
               t = sc.nextInt();
            }
            return t;
        }
    
}
