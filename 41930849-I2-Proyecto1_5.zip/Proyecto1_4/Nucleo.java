
/**
 * Esta clase representa el nucleo de la calculadora.
 * 
 * @author (Mario Finos) 
 * @version (1.0)
 */
public class Nucleo
{
    // variable para almacenar el resultado
    private int resultado;

    /**
     * Constructor de objetos de la clase Nucleo
     */
    public Nucleo()
    {
    }
    /**
     * Metodo set que modifica el valor de la variable de instancia resultado
     * @param nuevoResultado  el valor que utilizara para la modificacion
     */
    public void setResultado(int nuevoResultado){
        resultado = nuevoResultado;
    }
    /**
     * Metodo get que nos retornara el valor de la variable resultado
     */
    public int getResultado(){
        return resultado;
    }

    /**
     * Metodo que realiza el calculo de la suma
     * 
     * @param  y   el valor a utilizar para el calculo
     */
    public void suma(int y){
        resultado = resultado + y;
    }
    /**
     * Metodo que realiza el calculo de la multiplicacion
     * 
     * @param  y   el valor a utilizar para el calculo
     */
    public void multiplicar(int y){
        resultado = resultado * y;
    }
    /**
     * Metodo que realiza el calculo de la resta
     * 
     * @param  y   el valor a utilizar para el calculo
     */
    public void resta(int y){
        resultado = resultado - y;
    }
    /**
     * Metodo que realiza el calculo de la division
     * 
     * @param  y   el valor a utilizar para el calculo
     */
    public void division(int y){
        resultado = resultado / y;
    }
}
