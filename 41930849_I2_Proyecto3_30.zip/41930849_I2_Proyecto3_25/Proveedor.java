
/**
 * Clase Proveedor que permite almacenar lo datos de un proveedor.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Proveedor
{
    private String empresa;
    /**
     * Constructor de objetos de la clase Proveedor
     */
    public Proveedor()
    {
        
        
    }
    /**
     * Permite ingresar el nombre de la empresa de donde trabaja el proveedor
     * @param String nombre de la empresa
     */
    public void setEmpresa(String nuevaEmpresa){
        this.empresa=nuevaEmpresa;
    }
    /**
     * Permite obtener el nombre de la empresa de donde trabaja el proveedor
     * @return String nombre de la empresa
     */
    public String getEmpresa(){
        return empresa;
    }
}
