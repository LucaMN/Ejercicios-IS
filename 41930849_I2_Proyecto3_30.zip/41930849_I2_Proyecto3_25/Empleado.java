/**
 * Clase Proveedor que permite almacenar lo datos de un Empleado.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Empleado
{
    private String horaDeIngreso;
    /**
     * Constructor de objetos de la clase Empleado
     */
    public Empleado()
    {
        
        
    }
    /**
     * Permite ingresar la hora de ingreso de un empleado
     * @param String hora de ingreso
     */
    public void setHoraDeIngreso(String nuevaHora){
        this.horaDeIngreso=nuevaHora;
    }
    /**
     * Permite obtener la hora de ingreso de un Empleado
     * @return String hora de ingreso
     */
    public String getHoraDeIngreso(){
        return horaDeIngreso;
    }
   
}
