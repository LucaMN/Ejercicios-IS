
/**
 * Clase “Cliente” que permite almacenar los datos de los clientes
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Cliente extends Persona
{
    private String nacionalidad;
    /**
     * Constructor de objectos de la clase Cliente
     */
    public Cliente()
    {
       
    }
    /**
     * Permite ingresar una nacionalidad
     * @param String  nacionalidad del cliente.
     */
    public void setNacionalidad(String nuevaNacionalidad){
        this.nacionalidad = nuevaNacionalidad;
    }
    /**
     * Permite obtener el nombre de la nacionalidad
     * @return String  nacionalidad del cliente
     */
    public String getNacionalidad(){
        return nacionalidad;
    }
}
