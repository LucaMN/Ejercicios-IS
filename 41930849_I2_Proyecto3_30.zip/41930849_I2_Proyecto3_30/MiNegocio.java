import java.util.*;
/**
 * Almacena personas en un arraylist y muestra un mensaje sobre ellas
 * 
 * @author (Lucas Nuñez) 
 * @version (v1)
 */
public class MiNegocio
{
    private ArrayList<Persona> personas;
    /**
     * Constructor de objetos de la clase MiNegocio
     */
    public MiNegocio()
    {
        personas = new ArrayList<Persona>();
    }
    /**
     * Agrega personas al arraylist personas
     * @param Persona un dato de tipo persona
     */
    public void agregarPersona(Persona persona){
        personas.add(persona);
    }
    /**
     * Recorre el arrayList personas e imprime un texto con un mensaje
     */
    public void listar(){
        for(Persona persona : personas){
            System.out.println(persona.quienSoy());
        }
    }
}
