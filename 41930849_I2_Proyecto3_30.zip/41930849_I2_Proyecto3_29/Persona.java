
/**
 * Clase Persona que permite almacenar los datos de una persona.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Persona
{
    private int dni;
    private String nombre;
    /**
     * Constructor de objetos de la  clase Persona
     */
    public Persona()
    {
        
        
    }

    /**
     * Permite ingresar el numero de dni de la Persona
     * @param int numero de dni
     */
    public void setDni(int nuevoDni){
        this.dni = nuevoDni;
    }
    /**
     * Permite obtener el numero de dni de la Persona
     * @return int numero de dni
     */
    public int getDni(){
        return dni;
    }
    /**
     * Permite ingresar el nombre de la Persona
     * @para String nombre de la Persona
     */
    public void setNombre(String nuevoNombre){
        this.nombre=nuevoNombre;
    }
    /**
     * Permite obtener el nombre de la Persona
     * @return String nombre de la Persona
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Metodo que sirve para la sobreescritura
     * @return String null
     * 
     */
    public String quienSoy(){
        return null;
    }
}
