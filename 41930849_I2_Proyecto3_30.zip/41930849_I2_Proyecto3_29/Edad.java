
/**
 * Clase edad que almacena una edad
 * 
 * @author (Lucas Nuñez) 
 * @version (v1)
 */
public class Edad extends Persona
{
    private int edad;

    /**
     * Constructor de objetos de la clase Edad
     */
    public Edad()
    {
        
    }

     /**
     * Permite ingresar la edad de la Persona
     * @param int edad de la Persona
     */
    public void setEdad(int nuevaEdad){
        this.edad = nuevaEdad;
    }
    /**
     * Permite obtener la edad de la Persona
     * @return int edad de la Persona
     */
    public int getEdad(){
        return edad;
    }
    /**
     * Metodo que sirve para la sobreescritura
     * @return String null
     * @Override
     */
    public String quienSoy(){
        return null;
    }
}
