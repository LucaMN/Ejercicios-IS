/**
 * Clase Proveedor que permite almacenar lo datos de un Empleado.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Empleado
{
    private int dni;
    private String nombre;
    private String horaDeIngreso;
    private int edad;
    /**
     * Constructor de objetos de la clase Empleado
     */
    public Empleado()
    {
        
        
    }
    /**
     * Permite ingresar el numero de dni del Empleado
     * @param int numero de dni
     */
    public void setDni(int nuevoDni){
        this.dni = nuevoDni;
    }
    /**
     * Permite obtener el numero de dni del Empleado
     * @return int numero de dni
     */
    public int getDni(){
        return dni;
    }
    /**
     * Permite ingresar el nombre del Empleado
     * @para String nombre del Empleado
     */
    public void setNombre(String nuevoNombre){
        this.nombre=nuevoNombre;
    }
    /**
     * Permite obtener el nombre del Empleado
     * @return String nombre del Empleado
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Permite ingresar la hora de ingreso de un empleado
     * @param String hora de ingreso
     */
    public void setHoraDeIngreso(String nuevaHora){
        this.horaDeIngreso=nuevaHora;
    }
    /**
     * Permite obtener la hora de ingreso de un Empleado
     * @return String hora de ingreso
     */
    public String getHoraDeIngreso(){
        return horaDeIngreso;
    }
    /**
     * Permite ingresar la edad del Empleado
     * @param int edad del Empleado
     */
    public void setEdad(int nuevaEdad){
        this.edad = nuevaEdad;
    }
    /**
     * Permite obtener la edad del Empleado
     * @return int edad del Empleado
     */
    public int getEdad(){
        return edad;
    }
}
