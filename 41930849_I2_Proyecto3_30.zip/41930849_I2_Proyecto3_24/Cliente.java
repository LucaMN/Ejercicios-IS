
/**
 * Clase “Cliente” que permite almacenar los datos de los clientes
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Cliente
{
    private int dni;
    private String nombre;
    private String nacionalidad;
    /**
     * Constructor de objectos de la clase Cliente
     */
    public Cliente()
    {
       
    }
    /**
     * Permite ingresar un Dni
     * @param int nuevo dni del cliente
     */
    public void setDni(int nuevoDni){
        this.dni=nuevoDni;
    }
    /**
     * Permite obtener el valor del Dni
     * @return int numero de dni del cliente
     */
    public int getDni(){
        return dni;
    }
    /**
     * Permite ingresar un nombre
     * @param String nuevo nombre del cliente
     */
    public void setNombre(String nuevoNombre){
        this.nombre = nuevoNombre;
    }
    /**
     * Permite obtener el  nombre
     * @return String  nombre del cliente
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Permite ingresar una nacionalidad
     * @param String  nacionalidad del cliente.
     */
    public void setNacionalidad(String nuevaNacionalidad){
        this.nacionalidad = nuevaNacionalidad;
    }
    /**
     * Permite obtener el nombre de la nacionalidad
     * @return String  nacionalidad del cliente
     */
    public String getNacionalidad(){
        return nacionalidad;
    }
}
