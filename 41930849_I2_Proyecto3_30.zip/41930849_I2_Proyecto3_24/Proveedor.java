
/**
 * Clase Proveedor que permite almacenar lo datos de un proveedor.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Proveedor
{
    private int dni;
    private String nombre;
    private String empresa;
    private int edad;
    /**
     * Constructor de objetos de la clase Proveedor
     */
    public Proveedor()
    {
        
        
    }
    /**
     * Permite ingresar el numero de dni del proveedor
     * @param int numero de dni
     */
    public void setDni(int nuevoDni){
        this.dni = nuevoDni;
    }
    /**
     * Permite obtener el numero de dni del proveedor
     * @return int numero de dni
     */
    public int getDni(){
        return dni;
    }
    /**
     * Permite ingresar el nombre del proveedor
     * @para String nombre del proveedor
     */
    public void setNombre(String nuevoNombre){
        this.nombre=nuevoNombre;
    }
    /**
     * Permite obtener el nombre del proveedor
     * @return String nombre del proveedor
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Permite ingresar el nombre de la empresa de donde trabaja el proveedor
     * @param String nombre de la empresa
     */
    public void setEmpresa(String nuevaEmpresa){
        this.empresa=nuevaEmpresa;
    }
    /**
     * Permite obtener el nombre de la empresa de donde trabaja el proveedor
     * @return String nombre de la empresa
     */
    public String getEmpresa(){
        return empresa;
    }
    /**
     * Permite ingresar la edad del proveedor
     * @param int edad del proveedor
     */
    public void setEdad(int nuevaEdad){
        this.edad = nuevaEdad;
    }
    /**
     * Permite obtener la edad del proveedor
     * @return int edad del proveedor
     */
    public int getEdad(){
        return edad;
    }
}
